import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras.models import Model
def autoencoder_model():
    input = layers.Input(shape=(28, 28, 1))

    # Encoder
    x = layers.Conv2D(32, (3, 3), activation="relu", padding="same")(input)
    x = layers.MaxPooling2D((2, 2), padding="same")(x)
    x = layers.Conv2D(32, (3, 3), activation="relu", padding="same")(x)
    x = layers.MaxPooling2D((2, 2), padding="same")(x)
    x = layers.Flatten()(x)
    x = layers.Dense(700, activation = 'relu')(x)
    print(x.shape)
    # Decoder
    x = layers.Dense(400, activation='relu')(x)
    x = layers.Dense(784, activation = 'sigmoid')(x)
    # x = layers.Conv2DTranspose(32, (3, 3), strides=2, activation="relu", padding="same")(x)
    # x = layers.Conv2DTranspose(32, (3, 3), strides=2, activation="relu", padding="same")(x)
    # x = layers.Conv2D(1, (3, 3), activation="sigmoid", padding="same")(x)
    print(x.shape)
    # Autoencoder
    autoencoder = Model(input, x)
    autoencoder.compile(optimizer="adam", loss="binary_crossentropy")
    autoencoder.summary()
    return autoencoder