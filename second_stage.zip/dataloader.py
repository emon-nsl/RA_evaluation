from tensorflow.keras.datasets import mnist
import numpy as np
import cv2
def get_data():
    # Since we only need images from the dataset to encode and decode, we
    # won't use the labels.
    (train_input, train_y), (test_input, test_y) = mnist.load_data()


    train_list = []
    for i in train_y:
        img = cv2.imread('synth_img/digit_number_img_'+str(i)+'.jpg', 0)
        img = cv2.resize(img, (28, 28))
        img = np.reshape(img, (784,))
        train_list.append(img)
    #     break

    for i in test_y:
        img = cv2.imread('synth_img/digit_number_img_'+str(i)+'.jpg', 0)
        img = cv2.resize(img, (28, 28))
        img = np.reshape(img, (784,))
        train_list.append(img)
    #     break
    targets = np.array(train_list)
    input_img = np.concatenate((train_input, test_input), axis=0)
    #normalize
    targets = preprocess_targets(targets)
    input_img = preprocess_targets(input_img)
    print('after preprocess',np.max(input_img), np.max(targets))
    #after preprocess
    print(input_img.shape, targets.shape)
    return input_img, targets
def preprocess(array):
    """
    Normalizes the supplied array and reshapes it into the appropriate format.
    """

    array = array.astype("float32") / 255.0
    array = np.reshape(array, (len(array), 28, 28, 1))
    return array

def preprocess_targets(array):
    """
    Normalizes the supplied array and reshapes it into the appropriate format.
    """

    array = array.astype("float32") / 255.0
#     array = np.reshape(array, (len(array), 28, 28, 1))
    return array

# trainx, trainy, testx, testy = get_data()