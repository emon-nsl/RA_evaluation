from autoencoder import autoencoder_model
from dataloader import get_data
import numpy as np
import matplotlib.pyplot as plt
import cv2

#get the model
model = autoencoder_model()
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=['accuracy'])

#load model weights
model.load_weights('modelh5/autoencoder.h5')

split_ratio = 0.25
X, Y = get_data()
no_val_data = int(split_ratio * len(X))
print('no of validation data is ',no_val_data)

trainx, valx, testx = X[no_val_data*2:], X[:no_val_data],X[no_val_data:no_val_data*2]

trainy, valy, testy = Y[2*no_val_data:], Y[:no_val_data], Y[no_val_data:no_val_data*2]
print('trainx',trainx.shape,'trainy' ,trainy.shape, 'valx',valx.shape, 'valy',valy.shape, 'testx',testx.shape,'testy', testy.shape)

train_evaluate = model.evaluate(x=trainx, y = trainy, batch_size=128, verbose=0)
test_evaluate = model.evaluate(x=testx, y = testy, batch_size=128, verbose=0)
val_evaluate = model.evaluate(x=valx, y = valy, batch_size=128, verbose=0)

print('train ', train_evaluate)
print('train ', test_evaluate)
print('train ', val_evaluate)

losses = [train_evaluate[0], test_evaluate[0], val_evaluate[0]]
accuracy = [train_evaluate[1], test_evaluate[1], val_evaluate[1]]

N = 3
# x = np.random.rand(N)
# y = np.random.rand(N)
colors = np.random.rand(N)
area = (30 * np.random.rand(N))**2  

plt.scatter(losses, accuracy, c=colors, alpha=0.5)
plt.show()