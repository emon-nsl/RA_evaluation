import tensorflow as tf
from dataloader import get_data #dataloader

from autoencoder import autoencoder_model

### train, test, val split
split_ratio = 0.25
X, Y = get_data()
no_val_data = int(split_ratio * len(X))
print('no of validation data is ',no_val_data)

trainx, valx, testx = X[no_val_data*2:], X[:no_val_data],X[no_val_data:no_val_data*2]

trainy, valy, testy = Y[2*no_val_data:], Y[:no_val_data], Y[no_val_data:no_val_data*2]
print('trainx',trainx.shape,'trainy' ,trainy.shape, 'valx',valx.shape, 'valy',valy.shape, 'testx',testx.shape,'testy', testy.shape)
# exit()

##train, test, val split end

##get the model

model = autoencoder_model()

##model

#tensorboard visualization

tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir="./logs")

#tensorboard visualization

hist = model.fit(
    x=trainx,
    y=trainy,
    epochs=500,
    batch_size=128,
    shuffle=True,
    validation_data=(valx, valy),
    callbacks=[tensorboard_callback]
)

#save the model for later use
model.save_weights('modelh5/autoencoder.h5')
