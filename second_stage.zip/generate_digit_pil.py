from PIL import Image

from PIL import ImageFont, Image
from PIL import ImageDraw
import numpy as np

# plot digit numbers (from 0 to 9):

for i in range(10):
    img = Image.new('RGB', (28,28), (250,250,250))
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype("times.ttf", 30)
    draw.text((5, -2),str(i),(0,0,0),font=font)
    npimg = np.array(img)
    npimg = 255 - npimg
    img = Image.fromarray(npimg)
    img.save('synth_img/digit_number_img_'+str(i)+'.jpg')
