from autoencoder import autoencoder_model
import numpy as np
import cv2

#get the model
model = autoencoder_model()

#load model weights
model.load_weights('modelh5/autoencoder.h5')

img_pth = 'test_data/2_3258test_.jpg'
img = cv2.imread(img_pth, 0)/255.
img = np.expand_dims(img, axis=0)
print(img.shape)

#predict 
predi_img = model.predict(img)
predi_img = np.reshape(predi_img, (28, 28))

#save the predicted image
cv2.imwrite('pred/predicted_img.jpg',predi_img*255)

